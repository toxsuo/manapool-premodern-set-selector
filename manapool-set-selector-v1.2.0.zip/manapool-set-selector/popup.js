const TARGET_SETS = [
  { name: "Scourge", id: "SCG" },
  { name: "Legions", id: "LGN" },
  { name: "Onslaught", id: "ONS" },
  { name: "Judgment", id: "JUD" },
  { name: "Torment", id: "TOR" },
  { name: "Odyssey", id: "ODY" },
  { name: "Apocalypse", id: "APC" },
  { name: "Seventh Edition", id: "7ED" },
  { name: "Planeshift", id: "PLS" },
  { name: "Invasion", id: "INV" },
  { name: "Prophecy", id: "PCY" },
  { name: "Nemesis", id: "NEM" },
  { name: "Mercadian Masques", id: "MMQ" },
  { name: "Urza's Destiny", id: "UDS" },
  { name: "Classic Sixth Edition", id: "6ED" },
  { name: "Urza's Legacy", id: "ULG" },
  { name: "Urza's Saga", id: "USG" },
  { name: "Exodus", id: "EXO" },
  { name: "Stronghold", id: "STH" },
  { name: "Tempest", id: "TMP" },
  { name: "Weatherlight", id: "WTH" },
  { name: "Fifth Edition", id: "5ED" },
  { name: "Visions", id: "VIS" },
  { name: "Mirage", id: "MIR" },
  { name: "Alliances", id: "ALL" },
  { name: "Homelands", id: "HML" },
  { name: "Chronicles", id: "CHR" },
  { name: "Ice Age", id: "ICE" },
  { name: "Fourth Edition", id: "4ED" }
];

const applyButton = document.getElementById('apply');
const statusEl = document.getElementById('status');
const resultsEl = document.getElementById('results');

applyButton.addEventListener('click', async () => {
  applyButton.disabled = true;
  resultsEl.hidden = true;
  statusEl.textContent = 'Reading the Set filter, including indented sub-sets…';

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https?:\/\/(www\.)?manapool\.com\//i.test(tab.url || '')) {
      throw new Error('Open a ManaPool seller page before applying the set selection.');
    }

    const injection = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      args: [TARGET_SETS],
      func: async (targetSets) => {
        const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
        const normalize = value => (value || '').replace(/\s+/g, ' ').trim().toLocaleLowerCase();
        const isChecked = el => el?.getAttribute('aria-checked') === 'true' || el?.getAttribute('data-state') === 'checked';
        const getCheckbox = id => {
          const el = id ? document.getElementById(id) : null;
          return el?.matches('button[role="checkbox"]') ? el : null;
        };
        const getLabels = () => [...document.querySelectorAll('label[data-label-root][for]')]
          .filter(label => getCheckbox(label.getAttribute('for')));
        const getIndent = label => {
          // In ManaPool's Set list, top-level sets have no pl-* class.
          // Child/sub-set rows use pl-7; deeper descendants use larger pl-* values.
          const row = label.closest('span');
          const classes = [...(row?.classList || [])];
          const paddingClass = classes.find(c => /^pl-\d+$/.test(c));
          return paddingClass ? Number(paddingClass.slice(3)) : 0;
        };

        // Locate and expand the Set filter.
        const getSetToggle = () => [...document.querySelectorAll('button[aria-expanded]')]
          .find(button => normalize(button.querySelector('p')?.textContent || button.textContent) === 'set');
        let setToggle;
        for (let attempt = 0; attempt < 30 && !setToggle; attempt++) {
          setToggle = getSetToggle();
          if (!setToggle) await pause(150);
        }
        if (!setToggle) {
          return { error: 'Could not locate the Set filter. Wait for the seller page to finish loading, then try again.' };
        }
        if (setToggle.getAttribute('aria-expanded') !== 'true') {
          setToggle.click();
          await pause(350);
        }

        // Wait for the filter options to render after expansion.
        let labels = getLabels();
        for (let attempt = 0; attempt < 30 && !labels.length; attempt++) {
          await pause(150);
          labels = getLabels();
        }

        // Resolve the 29 parent sets using the IDs confirmed in the supplied HTML.
        // Then collect every indented descendant that follows each parent before
        // the next top-level set. This includes Promos and Foreign Black Border.
        const requested = [];
        const missingParents = [];
        for (const target of targetSets) {
          const labelsNow = getLabels();
          let parentIndex = labelsNow.findIndex(label =>
            label.getAttribute('for') === target.id && normalize(label.textContent) === normalize(target.name)
          );
          if (parentIndex < 0) {
            parentIndex = labelsNow.findIndex(label => normalize(label.textContent) === normalize(target.name));
          }
          if (parentIndex < 0) {
            missingParents.push(target.name);
            continue;
          }
          const parentLabel = labelsNow[parentIndex];
          const parentIndent = getIndent(parentLabel);
          requested.push({ id: parentLabel.getAttribute('for'), name: target.name, kind: 'parent' });
          for (let i = parentIndex + 1; i < labelsNow.length; i++) {
            const child = labelsNow[i];
            const indent = getIndent(child);
            if (indent <= parentIndent) break;
            requested.push({
              id: child.getAttribute('for'),
              name: child.textContent.trim(),
              parent: target.name,
              kind: 'sub-set'
            });
          }
        }

        // Remove duplicate IDs while retaining the order shown in the Set filter.
        const uniqueRequested = [...new Map(requested.map(item => [item.id, item])).values()];
        const selectedNow = [];
        const alreadySelected = [];
        const failed = [];

        for (const item of uniqueRequested) {
          let checkbox = getCheckbox(item.id);
          let label = document.querySelector(`label[data-label-root][for="${CSS.escape(item.id)}"]`);
          if (!checkbox || !label) {
            failed.push(`${item.name}${item.parent ? ` (${item.parent})` : ''}`);
            continue;
          }

          if (isChecked(checkbox)) {
            alreadySelected.push(item.name + (item.parent ? ` — ${item.parent}` : ''));
            continue;
          }

          label.scrollIntoView({ block: 'nearest' });
          // Clicking the associated label activates ManaPool's custom checkbox
          // through its native label association. Fall back to the button if needed.
          label.click();
          for (let attempt = 0; attempt < 20; attempt++) {
            await pause(100);
            checkbox = getCheckbox(item.id);
            if (isChecked(checkbox)) break;
          }
          if (!isChecked(checkbox)) {
            checkbox = getCheckbox(item.id);
            checkbox?.click();
            for (let attempt = 0; attempt < 20; attempt++) {
              await pause(100);
              checkbox = getCheckbox(item.id);
              if (isChecked(checkbox)) break;
            }
          }

          checkbox = getCheckbox(item.id);
          if (isChecked(checkbox)) selectedNow.push(item.name + (item.parent ? ` — ${item.parent}` : ''));
          else failed.push(`${item.name}${item.parent ? ` (${item.parent})` : ''}`);
        }

        return {
          parentCount: targetSets.length,
          requestedCount: uniqueRequested.length,
          selectedNow,
          alreadySelected,
          failed,
          missingParents
        };
      }
    });

    const result = injection?.[0]?.result;
    if (!result) throw new Error('ManaPool did not return a result. Please try again.');
    if (result.error) throw new Error(result.error);

    statusEl.textContent = 'Finished. Review the results below.';
    document.getElementById('summary').textContent =
      `${result.selectedNow.length + result.alreadySelected.length} of ${result.requestedCount} options selected (${result.parentCount} parent sets and their indented sub-sets).`;

    const renderList = (id, items, emptyText) => {
      const list = document.getElementById(id);
      list.replaceChildren();
      if (!items.length) {
        const li = document.createElement('li');
        li.textContent = emptyText;
        list.append(li);
      } else {
        for (const name of items) {
          const li = document.createElement('li');
          li.textContent = name;
          list.append(li);
        }
      }
    };
    renderList('selected', result.selectedNow, 'None');
    renderList('already', result.alreadySelected, 'None');
    renderList('failed', [...result.failed, ...result.missingParents.map(name => `${name} (parent set not found)`)], 'No failures.');
    resultsEl.hidden = false;
  } catch (error) {
    statusEl.textContent = error.message || 'Something went wrong. Please try again.';
  } finally {
    applyButton.disabled = false;
  }
});
